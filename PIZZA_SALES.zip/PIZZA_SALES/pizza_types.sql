select *  from pizzahut.pizza_types;
